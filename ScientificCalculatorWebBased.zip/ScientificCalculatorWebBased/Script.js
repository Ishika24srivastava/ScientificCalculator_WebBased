// Variable Decalartion
var trignometryVisible = false;
var buttonClicked = true;
var InverseFunctionVariableBool = true;
var hyperbolicVariableBool = true;
var notation = false;
let angleUnit = 0;
let displayValue1 = '';
let displayValue2 = '';
let EvaulatedValue = '';
var disableButtons = false;
var infunctionOnce = 0;
var thatNumber = '';
var thatIndex = -1;
var functionKeyPressed = false;
var functionpi=false;
var leftBracketCount=0;
var rightBracketCount=0;
const myButton = document.getElementById("secondButton");

// Toggle Cases
function renderingTrigoButtons() {
    var renderingTrigoOptions = document.getElementById('trignometricFunction');
    if (renderingTrigoOptions.style.display === 'none') {
        renderingTrigoOptions.style.display = 'grid';
        trignometryVisible = true;
    } else {
        renderingTrigoOptions.style.display = 'none';
        trignometryVisible = false;
    }
}
function renderingFunctionButtons() {
    let moreFunctionButtons = document.getElementById('Functions');
    if (moreFunctionButtons.style.display === 'none') {
        moreFunctionButtons.style.display = 'grid';
    } else {
        moreFunctionButtons.style.display = 'none';
    }
}
function renderingbuttonTrignometricFunctions() {
    if (InverseFunctionVariableBool && hyperbolicVariableBool) {
        document.getElementById('sin').innerHTML = "sin<sup>-1</sup>";
        document.getElementById('cos').innerHTML = "cos<sup>-1</sup>";
        document.getElementById('tan').innerHTML = "tan<sup>-1</sup>";
        document.getElementById('sec').innerHTML = "sec<sup>-1</sup>";
        document.getElementById('csc').innerHTML = "csc<sup>-1</sup>";
        document.getElementById('cot').innerHTML = "cot<sup>-1</sup>";
        InverseFunctionVariableBool = false;
    }
    else if (InverseFunctionVariableBool == false && hyperbolicVariableBool) {
        document.getElementById('sin').innerHTML = "sin";
        document.getElementById('cos').innerHTML = "cos";
        document.getElementById('tan').innerHTML = "tan";
        document.getElementById('sec').innerHTML = "sec";
        document.getElementById('csc').innerHTML = "csc";
        document.getElementById('cot').innerHTML = "cot";
        InverseFunctionVariableBool = true;
    }
    else if (hyperbolicVariableBool == false && InverseFunctionVariableBool) {
        document.getElementById('sin').innerHTML = "sinh<sup>-1</sup>";
        document.getElementById('cos').innerHTML = "cosh<sup>-1</sup>";
        document.getElementById('tan').innerHTML = "tanh<sup>-1</sup>";
        document.getElementById('sec').innerHTML = "sech<sup>-1</sup>";
        document.getElementById('csc').innerHTML = "csch<sup>-1</sup>";
        document.getElementById('cot').innerHTML = "coth<sup>-1</sup>";
        InverseFunctionVariableBool = false;
    }
    else if (hyperbolicVariableBool == false && InverseFunctionVariableBool == false) {
        document.getElementById('sin').innerHTML = "sinh";
        document.getElementById('cos').innerHTML = "cosh";
        document.getElementById('tan').innerHTML = "tanh";
        document.getElementById('sec').innerHTML = "sech";
        document.getElementById('csc').innerHTML = "csch";
        document.getElementById('cot').innerHTML = "coth";
        InverseFunctionVariableBool = true;
    }
}
function renderinghyperBolic() {
    if (hyperbolicVariableBool) {
        document.getElementById('sin').innerHTML = "sinh";
        document.getElementById('cos').innerHTML = "cosh";
        document.getElementById('tan').innerHTML = "tanh";
        document.getElementById('sec').innerHTML = "sech";
        document.getElementById('csc').innerHTML = "csch";
        document.getElementById('cot').innerHTML = "coth";
        hyperbolicVariableBool = false;
    }
    else {
        if (InverseFunctionVariableBool = false) {
            document.getElementById('sin').innerHTML = "sin<sup>-1</sup>";
            document.getElementById('cos').innerHTML = "cos<sup>-1</sup>";
            document.getElementById('tan').innerHTML = "tan<sup>-1</sup>";
            document.getElementById('sec').innerHTML = "sec<sup>-1</sup>";
            document.getElementById('csc').innerHTML = "csc<sup>-1</sup>";
            document.getElementById('cot').innerHTML = "cot<sup>-1</sup>";
            InverseFunctionVariableBool = true;
        }
        else {
            document.getElementById('sin').innerHTML = "sin";
            document.getElementById('cos').innerHTML = "cos";
            document.getElementById('tan').innerHTML = "tan";
            document.getElementById('sec').innerHTML = "sec";
            document.getElementById('csc').innerHTML = "csc";
            document.getElementById('cot').innerHTML = "cot";
            hyperbolicVariableBool = true;
        }

    }

}
 function secondManipulationClick() {
    if (buttonClicked) {
        document.getElementById('XSquare').innerHTML = "x<sup>3</sup>";
        document.getElementById('underrootX').innerHTML = "<sup>3</sup><span>&#8730;</span>x";
        document.getElementById('xPower').innerHTML = "<sup>y</sup><span>&#8730;</span>x";
        document.getElementById('tenPower').innerHTML = "2<sup>x</sup>";
        document.getElementById('log').innerHTML = "log<sub>y</sub>x";
        document.getElementById('ln').innerHTML = "e<sup>x</sup>";
        buttonClicked = false;
    }
    else {
        document.getElementById('XSquare').innerHTML = "x<sup>2</sup>";
        document.getElementById('underrootX').innerHTML = "<sup>2</sup><span>&#8730;</span>x";
        document.getElementById('xPower').innerHTML = "x<sup>y</sup>";
        document.getElementById('tenPower').innerHTML = "10<sup>x</sup>";
        document.getElementById('log').innerHTML = "log";
        document.getElementById('ln').innerHTML = "ln";
        buttonClicked = true;
    }
}
myButton.onclick = secondManipulationClick;


document.addEventListener("keydown", function (event) {
    if (event.key >= "0" && event.key <= "9") {
        var buttonNumber = parseInt(event.key);
        var button = document.getElementById("button" + buttonNumber);
        button.click();
        button.classList.add("active");
        setTimeout(function () {
            button.classList.remove("active");
        }, 100);

    }
    else if (event.key === "+") {
        document.getElementById("plus").click();

    }
    else if (event.key === "-") {
        document.getElementById("minus").click();

    }
    else if (event.key === "*") {
        document.getElementById("multiplication").click();

    }
    else if (event.key === "/") {
        document.getElementById("divide").click();

    }
    else if (event.key === ".") {
        document.getElementById("decimal").click();

    }
    else if (event.key === "Enter") {
        document.getElementById("Enter").click();
        if (disableButtons) {
            EnableButtonCases();
        }
    }
    else if (event.key === "Backspace") {
        if (disableButtons) {
            EnableButtonCases();
        }
        let backspace = document.getElementById("backspace");
        backspace.click();
        backspace.classList.add("active");
        setTimeout(function () {
            backspace.classList.remove("active");
        }, 100);

    }
    else if (event.key === "Escape") {
        document.getElementById("clear").click();
    }
});
for (var i = 0; i <= 9; i++) {
    document.getElementById("button" + i).addEventListener("click", function () {
        calculationValue(this.textContent);
        if (disableButtons) {
            EnableButtonCases();
        }
    });
}
function plusCalculation() {
    calculationValue('+');
}
function minusCalculation() {
    calculationValue('-');
}
function multiplyCalculation() {
    calculationValue('*');
}
function divideCalculation() {
    calculationValue('/');
}
function decimalCalculation() {
    calculationValue('.');
}

//Constant Decalartion
const valueFactroail = 7;
const factorialValue = [
    0.99999999999980993,
    676.5203681218851,
    -1259.1392167224028,
    771.32342877765313,
    -176.61502916214059,
    12.507343278686905,
    -0.13857109526572012,
    9.9843695780195716e-6,
    1.5056327351493116e-7
];
var xtoThePowerYBoolean = false
var xtoThePowerYBooleanHelper = false;
function calculationValue(value) {
    if (value >= 0 && value <= 9 || value == '.') {
        displayValue2 += value;
        document.getElementById('secondLinedisplay').innerText = displayValue2;
    }
      
    else {
        if (value == '+' || value == '-' || value == '*' || value == '/' || value == '%' || value == '^') {
            infunctionOnce = 0;

            EvaulatedValue += displayValue2 + value;
            if (value == '%') {
                displayValue1 += displayValue2 + 'Mod';
            }
            else if (value == '/') {
                displayValue1 += displayValue2 + '÷';
            }
            else if (value == '^' && xtoThePowerYBoolean && xtoThePowerYBooleanHelper == false) {
                EvaulatedValue += '(1/';
                displayValue1 += displayValue2 + 'yroot'
                xtoThePowerYBooleanHelper = true;
            }

            else {

                if (functionKeyPressed == true) {
                    displayValue1 += value;
                    functionKeyPressed = false;
                }
                else {
                    displayValue1 += displayValue2 + value;
                }
            }
        }
        else {
            displayValue1 += value;
        }
        displayValue2 = '';
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    }
   

function clearScreen() {
    displayValue1 = '';
    displayValue2 = '';
    EvaulatedValue = '';
    infunctionOnce = 0;
    functionKeyPressed = false;
    thatIndex = -1
    document.getElementById('firstLineDisplay').innerText = '';
    document.getElementById('secondLinedisplay').innerText = '';
}
function backspace() {
    // if we click this after enter
    let tempValue = document.getElementById('firstLineDisplay').innerText;
    let lastIndex = tempValue.length - 1;
    if (tempValue[lastIndex] == '=') {
        document.getElementById('firstLineDisplay').innerText = '';
        displayValue1 = '';
        EvaulatedValue = '';
    }
    else {
        if (displayValue2.length == 0) {
            displayValue2 = '';
            document.getElementById('secondLinedisplay').innerText = '0';
        }
        else {
            displayValue2 = displayValue2.slice(0, -1);
            if (displayValue2.length == 0) {
                displayValue2 = '';
                document.getElementById('secondLinedisplay').innerText = '0';
            }
            else {
                document.getElementById('secondLinedisplay').innerText = displayValue2;
            }
        }

    }
}
// Final Calculation
function anwserCalculation() {
    try {
        let lastIndex = EvaulatedValue.length - 1;
        let lastElement = EvaulatedValue[lastIndex]
        if (lastElement == '+' || lastElement == '-' || lastElement == '*' || lastElement == '/' || lastElement == '%' || lastElement == '^' || EvaulatedValue.length == 0) {
            if ((document.getElementById('secondLinedisplay').innerText)[0] == '-') {
                EvaulatedValue += '(' + document.getElementById('secondLinedisplay').innerText + ')';
                if (functionKeyPressed == false) {
                    displayValue1 += document.getElementById('secondLinedisplay').innerText;
                }
            }
            else {
                EvaulatedValue += document.getElementById('secondLinedisplay').innerText;
                if (functionKeyPressed == false) {
                    displayValue1 += document.getElementById('secondLinedisplay').innerText;
                }
            }
        }
        console.log(EvaulatedValue)
        const result = bodmasApply(EvaulatedValue)
        displayValue1 += '=';
        displayValue2 = result.toString();
        EvaulatedValue = '';
        document.getElementById('secondLinedisplay').innerText = result;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
        displayValue1 = '';
        infunctionOnce = 0;
        thatIndex = -1;
    } catch (error) {
        displayValue1 = '';
        document.getElementById('secondLinedisplay').innerText = 'Error';
        DisableBuutonExceptionCases();
    }
}
document.getElementById("notationButton").addEventListener("click", function () {
    if (notation == false) {
        document.getElementById("notationButton").innerText = "E-F";
        notation = true;
    }
    else {
        document.getElementById("notationButton").innerText = "F-E";
        notation = false;
    }
})
document.getElementById("angleButton").addEventListener("click", function () {
    angleUnit = angleUnit + 1;
    switch (angleUnit) {
        case 1:
            document.getElementById("angleButton").innerText = "RAD";
            break;
        case 2:
            document.getElementById("angleButton").innerText = "GRAD";
            break;
        case 3:
            document.getElementById("angleButton").innerText = "DEG";
            angleUnit = 0;
            break;
    }
})
document.getElementById("history").addEventListener("click", function () {
    let historyBlock = document.getElementById('historyBlock');
    let memoryBlock = document.getElementById('memoryBlock');
    if (historyBlock) {
        if (historyBlock.style.display == 'none') {
            historyBlock.style.display = 'block';
            memoryBlock.style.display = 'none';
        }
        else {
            historyBlock.style.display = 'none';
        }
    }
})
document.getElementById("memory").addEventListener("click", function () {
    let memoryBlock = document.getElementById('memoryBlock');
    let historyBlock = document.getElementById('historyBlock');
    if (memoryBlock.style.display === 'none') {
        memoryBlock.style.display = 'block';
        historyBlock.style.display = 'none';
    } else {
        memoryBlock.style.display = 'none';
    }
})

function DisableBuutonExceptionCases() {
    const buttonIds = ['secondButton', 'pi', 'e', 'XSquare', 'oneByX', 'modX', 'exp', 'mod', 'underrootX', 'leftBracket', 'rightBracket', 'factorial', 'divide', 'xPower', 'multiplication', 'tenPower', 'minus', 'log', 'plus', 'ln', 'neogateCalculation', 'decimal', 'button_trigo', 'button_function'];
    for (let i = 0; i < buttonIds.length; i++) {
        const button = document.getElementById(buttonIds[i]);
        if (button) {
            button.disabled = true;
        }
    }
    disableButtons = true;
}
function EnableButtonCases() {
    const buttonIds = ['secondButton', 'pi', 'e', 'XSquare', 'oneByX', 'modX', 'exp', 'mod', 'underrootX', 'leftBracket', 'rightBracket', 'factorial', 'divide', 'xPower', 'multiplication', 'tenPower', 'minus', 'log', 'plus', 'ln', 'neogateCalculation', 'decimal', 'button_trigo', 'button_function'];

    for (let i = 0; i < buttonIds.length; i++) {
        const button = document.getElementById(buttonIds[i]);
        if (button) {
            button.disabled = false;
        }
    }
    disableButtons = false;
}
// math functions ====================================================================================

function piCalculation() 
{
    functionpiClicked = true;
    displayValue2 = Math.PI;
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}

// Function to handle the e value
function eCalculation() 
{
    document.getElementById('secondLinedisplay').innerText = Math.E;
}


let xForLog;
let baseForLog;

function naturalLogCalculation() {
    let displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();

    if (baseForLog !== undefined && xForLog !== undefined) {
        let x = parseFloat(xForLog);
        let y = parseFloat(baseForLog);
        let result;
        if (!isNaN(x) && !isNaN(y) && x > 0 && y > 0 && y !== 1) {
            result = Math.log(x) / Math.log(y);
            displayValue1 += xForLog + 'log<sub>' + baseForLog + '</sub>';
            displayValue2 = result;
            xForLog = undefined; 
            baseForLog = undefined; 
        } 
        else
        {
            displayValue1 = "Invalid input";
            displayValue2 = "";
        }
    } 
    else
    {
        displayValue1 += 'log(' + thatNumber + ')';
        let tempValue = Math.log10(displayValue2);
        displayValue2 = tempValue;
        thatNumber = 'log(' + thatNumber + ')';
    }

    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerHTML = displayValue1;
}

function setXForLog(x) 
{
    xForLog = x;
    document.getElementById('firstLineDisplay').innerText = xForLog + 'log';
}

function setBaseForLog(base) 
{
    baseForLog = base;
    document.getElementById('firstLineDisplay').innerText += '<sub>' + baseForLog + '</sub>';
}

function linBaseECalculation()
 {
    if (document.getElementById('ln').innerText == 'ln') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        formating();
        displayValue1 += 'ln(' + thatNumber + ')';
        let tempValue = Math.log(displayValue2);
        displayValue2 = tempValue;
        thatNumber = 'ln(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        formating();
        displayValue1 += 'e^(' + thatNumber + ')';
        let tempValue = Math.exp(displayValue2);
        displayValue2 = tempValue;
        thatNumber = 'e^(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }

}

function squarerootCalculation() 
{
    
    if (buttonClicked)
   {        
     
     displayValue2 = document.getElementById('secondLinedisplay').innerText;
     let tempnumber = parseFloat(displayValue2);
    try {
        if (tempnumber < 0) {
          throw new Error("Invalid input");
        }
       let tempValue = Math.sqrt(tempnumber);
       displayValue1 = '√(' + tempnumber + ')';
       displayValue2 = tempValue;
       thatNumber = '√(' + tempnumber + ')';
       document.getElementById('firstLineDisplay').innerText = displayValue1;
       document.getElementById('secondLinedisplay').innerText = displayValue2;
    } catch (error) {
     displayValue1 = '';
     displayValue2 = '';
     EvaulatedValue = '';
     document.getElementById('secondLinedisplay').innerText = 'Invalid Input';
     DisableBuutonExceptionCases();
 }

    } 
    else 
    {
       displayValue2 = document.getElementById('secondLinedisplay').innerText;
       let tempnumber = parseFloat(displayValue2);
       try {
           let tempValue = Math.cbrt(tempnumber);
           displayValue1 = '∛(' + tempnumber + ')';
           displayValue2 = tempValue;
           thatNumber = '∛(' + tempnumber + ')';
           document.getElementById('firstLineDisplay').innerText = displayValue1;
           document.getElementById('secondLinedisplay').innerText = displayValue2;
       } catch (error) {
           displayValue1 = '';
           displayValue2 = '';
           EvaulatedValue = '';
           document.getElementById('secondLinedisplay').innerText = 'Invalid Input';
           DisableBuutonExceptionCases();
       }
    }
}



function squareCalculation() {
    if (document.getElementById('XSquare').innerHTML == "x<sup>2</sup>") {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        formating();
        displayValue1 += 'sqr(' + thatNumber + ')';
        let tempValue = Math.pow(displayValue2, 2);
        displayValue2 = tempValue;
        thatNumber = 'sqr(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        formating();
        displayValue1 += 'cube(' + thatNumber + ')';
        let tempValue = Math.pow(displayValue2, 3);
        displayValue2 = tempValue;
        thatNumber = 'cube(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
}


function inverse() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += '1/(' + thatNumber + ')';
    document.getElementById('firstLineDisplay').innerText = displayValue1;
    let tempValue = 1 / displayValue2;;
    displayValue2 = tempValue;
    thatNumber = '1/(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
}

function abs()
 {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += 'abs(' + thatNumber + ')';
    let tempValue = Math.abs(displayValue2);
    displayValue2 = tempValue;
    thatNumber = 'abs(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}
function leftBracket() {
    leftBracketCount++;
    document.getElementById('leftBracket').innerHTML = `(<sub>${leftBracketCount}</sub>`;
    if (EvaulatedValue.length == 0) {
        EvaulatedValue = '(';
        displayValue1 = '('
    }
    else {
        EvaulatedValue += '(';
        displayValue1 += '('
    }
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}
function rightBracket() {
    if (rightBracketCount < leftBracketCount) {
        rightBracketCount++;

        if (leftBracketCount - rightBracketCount == 0) {
            rightBracketCount = 0;
            leftBracketCount = 0;
            document.getElementById('leftBracket').innerHTML = `(`;

            let lastOp = EvaulatedValue[EvaulatedValue.length - 1]
            if (lastOp >= '0' && lastOp <= '9' || lastOp == ')') {
                EvaulatedValue += ')';
                displayValue1 += ')'
            }
            else {
                displayValue1 += document.getElementById('secondLinedisplay').innerText;
                EvaulatedValue += document.getElementById('secondLinedisplay').innerText;
                EvaulatedValue += ')';
                displayValue1 += ')'
            }
        }
        else if (leftBracketCount >= 0) {
            document.getElementById('leftBracket').innerHTML = `(<sub>${leftBracketCount - rightBracketCount}</sub>`;
            let lastOp = EvaulatedValue[EvaulatedValue.length - 1]
            if (lastOp >= '0' && lastOp <= '9' || lastOp == ')') {
                displayValue1
                EvaulatedValue += ')';
                displayValue1 += ')'
            }
            else {
                displayValue1 += document.getElementById('secondLinedisplay').innerText;
                EvaulatedValue += document.getElementById('secondLinedisplay').innerText;
                EvaulatedValue += ')';
                displayValue1 += ')'
            }
        }
        document.getElementById('firstLineDisplay').innerText = displayValue1;

    }
}

// Function to handle x^y and Y√x button click
function xPowerYCalculation() {
    if (document.getElementById('xPower').innerHTML == "x<sup>y</sup>") {
        calculationValue('^'); 
    } else {
        xtoThePowerYBoolean = true;
        calculationValue('^');
    }
}

function neogateCalculation() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += 'negate(' + thatNumber + ')';
    if (parseFloat(displayValue2)) {
        if (displayValue2 <= 0) {
            displayValue2 = Math.abs(displayValue2)
        }
        else {
            displayValue2 = 0 - displayValue2;
        }
    }
    thatNumber = 'negate(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;

}
function formating() {
    functionKeyPressed = true;
    if (infunctionOnce == 0) {
        thatNumber = displayValue2;
        thatIndex = displayValue1.length;
    }
    if (displayValue1.length - thatNumber.length >= 0 && infunctionOnce != 0) {
        displayValue1 = displayValue1.slice(0, displayValue1.length - thatNumber.length);
    }
    infunctionOnce++;
}
function factorialCalculation() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    let tempnumber = parseFloat(displayValue2)
    let tempnumber2 = parseInt(displayValue2)
    formating();
    try {
        displayValue1 += 'fact(' + thatNumber + ')';
        if (tempnumber < 0) {
            throw new Error("Invalid input");
        }
        let tempValue = FactorialHandle(tempnumber + 1);
        if (tempnumber == tempnumber2) {
            displayValue2 = Math.round(tempValue)
        }
        else {
            displayValue2 = tempValue
        }
        thatNumber = 'fact(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    catch {
        displayValue1 = '';
        displayValue2 = '';
        EvaulatedValue = '';
        document.getElementById('secondLinedisplay').innerText = 'Invalid Input';
        DisableBuutonExceptionCases();
    }
}
function FactorialHandle(z) {
    if (z < 0.5) {
        return Math.PI / (Math.sin(Math.PI * z) * FactorialHandle(1 - z));
    }
    z -= 1;
    let x = factorialValue[0];
    for (let i = 1; i < valueFactroail + 2; i++) {
        x += factorialValue[i] / (z + i);
    }
    let t = z + valueFactroail + 0.5;
    return Math.sqrt(2 * Math.PI) * Math.pow(t, z + 0.5) * Math.exp(-t) * x;
}

//  Toggle Functions  Caluclation 
function rand() {
    displayValue2 = Math.random();
    document.getElementById('secondLinedisplay').innerText = displayValue2;
}
function floor() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += 'floor(' + thatNumber + ')';
    let tempValue = Math.floor(displayValue2);
    displayValue2 = tempValue;
    thatNumber = 'floor(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}
function ceiling() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += 'ceil(' + thatNumber + ')';
    let tempValue = Math.ceil(displayValue2);
    displayValue2 = tempValue;
    thatNumber = 'ceil(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}
function tenPowerCalculation() {
    if (document.getElementById('tenPower').innerHTML == "10<sup>x</sup>") {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        formating();
        displayValue1 += '10^(' + thatNumber + ')';
        let tempValue = Math.pow(10, parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = '10^(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        formating();
        displayValue1 += '2^(' + thatNumber + ')';
        let tempValue = Math.pow(2, parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = '2^(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
}

// Functions Method
function ConvertToDMS(angle1) {
    let degrees = Math.floor(angle1);
    let minutes = (angle1 - degrees) * 60;
    let minutesInt = Math.floor(minutes);
    let seconds = (minutes - minutesInt) * 60;
    let result = degrees + minutesInt / 100.0 + seconds / 10000.0;
    return result;
}
function DMSToDegree(angle1) {
    let degrees = Math.floor(angle1);
    let minutes = (angle1 - degrees);
    let result = degrees + (minutes / 60);
    return result;
}
function dms() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += 'dms(' + thatNumber + ')';
    let tempValue = ConvertToDMS(displayValue2);
    displayValue2 = tempValue;
    thatNumber = 'dms(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}
function deg() {
    displayValue2 = document.getElementById('secondLinedisplay').innerText;
    formating();
    displayValue1 += 'degrees(' + thatNumber + ')';
    let tempValue = DMSToDegree(displayValue2);
    displayValue2 = tempValue;
    thatNumber = 'degrees(' + thatNumber + ')';
    document.getElementById('secondLinedisplay').innerText = displayValue2;
    document.getElementById('firstLineDisplay').innerText = displayValue1;
}

// Trigo function==================================================================================================================
function sinFunction() {
    if (document.getElementById('sin').innerText == 'sin') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'sin₀'
        }
        else if (status == 'RAD') {
            symbol = 'sin<sub>ᵣ<.sub>'
        }
        else {
            symbol = 'sin<sub>₉<.sub>'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = Sine(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('sin').innerHTML == 'sin<sup>-1</sup>') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'sin₀⁻¹'
        }
        else if (status == 'RAD') {
            symbol = 'sin<sub>ᵣ<.sub>⁻¹'
        }
        else {
            symbol = 'sin<sub>₉<.sub>⁻¹'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = SineInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('sin').innerText == 'sinh') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'sinh';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = SineHyp(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('sin').innerHTML == 'sinh<sup>-1</sup>') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'sinh⁻¹';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = SineHypInverse(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
}
function cosFunction() {
    if (document.getElementById('cos').innerText == 'cos') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'cos<sub>₀</sub>'
        }
        else if (status == 'RAD') {
            symbol = 'cos<sub>ᵣ<.sub>'
        }
        else {
            symbol = 'cos<sub>₉<.sub>'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = Cosine(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('cos').innerHTML == 'cos<sup>-1</sup>') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'cos₀⁻¹'
        }
        else if (status == 'RAD') {
            symbol = 'cos<sub>ᵣ<.sub>⁻¹'
        }
        else {
            symbol = 'cos<sub>₉<.sub>⁻¹'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CosineInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('cos').innerText == 'cosh') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'cosh';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CosineHyp(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('cos').innerHTML == 'cosh<sup>-1</sup>') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'cosh⁻¹';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CosineHypInverse(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
}
function tanFunction() {
    if (document.getElementById('tan').innerText == 'tan') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'tan₀'
        }
        else if (status == 'RAD') {
            symbol = 'tan<sub>ᵣ<.sub>'
        }
        else {
            symbol = 'tan<sub>₉<.sub>'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = Tangent(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('tan').innerHTML == 'tan<sup>-1</sup>') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'tan₀⁻¹'
        }
        else if (status == 'RAD') {
            symbol = 'tan<sub>ᵣ<.sub>⁻¹'
        }
        else {
            symbol = 'tan<sub>₉<.sub>⁻¹'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = TangentInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('tan').innerText == 'tanh') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'tanh';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = TangentHyp(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('tan').innerHTML == 'tanh<sup>-1</sup>') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'tanh';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = TangentHypInverse(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }

}
function secFunction() {
    if (document.getElementById('sec').innerText == 'sec') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'sec₀'
        }
        else if (status == 'RAD') {
            symbol = 'sec<sub>ᵣ<.sub>'
        }
        else {
            symbol = 'sec<sub>₉<.sub>'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = Sec(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('sec').innerHTML == 'sec<sup>-1</sup>') {
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'sec₀⁻¹'
        }
        else if (status == 'RAD') {
            symbol = 'sec<sub>ᵣ<.sub>⁻¹'
        }
        else {
            symbol = 'sec<sub>₉<.sub>⁻¹'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = SecInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('sec').innerText == 'sech') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'sech';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = SecHyp(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if (document.getElementById('sec').innerHTML == 'sech<sup>-1</sup>') {
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'sech⁻¹';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = SecHypInverse(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
}
function cscFunction() {
    if(document.getElementById('csc').innerText=='csc'){
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'csc₀'
        }
        else if (status == 'RAD') {
            symbol = 'csc<sub>ᵣ<.sub>'
        }
        else {
            symbol = 'csc<sub>₉<.sub>'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = Cosec(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if(document.getElementById('csc').innerHTML=='csc<sup>-1</sup>'){
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'csc₀⁻¹'
        }
        else if (status == 'RAD') {
            symbol = 'csc<sub>ᵣ<.sub>⁻¹'
        }
        else {
            symbol = 'csc<sub>₉<.sub>⁻¹'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CosecInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if(document.getElementById('csc').innerText=='csch'){
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'csch';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CosecHyp(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if(document.getElementById('csc').innerHTML=='csch<sup>-1</sup>'){
       displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'csch⁻¹';
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CosecHypInverse(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }

   
}
function cotFunction() {
    if(document.getElementById('cot').innerText=='cot'){
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'cot₀'
        }
        else if (status == 'RAD') {
            symbol = 'cot<sub>ᵣ<.sub>'
        }
        else {
            symbol = 'cot<sub>₉<.sub>'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = Cot(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    if(document.getElementById('cot').innerHTML=='cot<sup>-1</sup>'){
        let status = document.getElementById('angleButton').innerText;
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = '';
        formating();
        if (status == 'DEG') {
            symbol = 'cot₀⁻¹'
        }
        else if (status == 'RAD') {
            symbol = 'cot<sub>ᵣ<.sub>⁻¹'
        }
        else {
            symbol = 'cot<sub>₉<.sub>⁻¹'
        }
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CotInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    else if(document.getElementById('cot').innerText=='coth'){
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'coth';
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CotHyp(parseFloat(displayValue2));
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }
    if(document.getElementById('cot').innerHTML=='coth<sup>-1</sup>'){
        displayValue2 = document.getElementById('secondLinedisplay').innerText;
        let symbol = 'coth⁻¹';
        formating();
        displayValue1 += symbol + '(' + thatNumber + ')';
        let tempValue = CotHypInverse(parseFloat(displayValue2), status);
        displayValue2 = tempValue;
        thatNumber = symbol + '(' + thatNumber + ')';
        document.getElementById('secondLinedisplay').innerText = displayValue2;
        document.getElementById('firstLineDisplay').innerText = displayValue1;
    }  
}
// Function for "exp" button functionality
document.getElementById('exp').addEventListener('click', function() {
    // Get the current value in the display
    let currentValue = parseFloat(document.getElementById('secondLinedisplay').innerText);

    // Check if currentValue is operand1 valid number
    if (!isNaN(currentValue)) {
        // Calculate the exponential value of the current value
        let exponentialValue = Math.exp(currentValue);

        // Check if the exponential value is operand1 valid number
        if (!isNaN(exponentialValue)) {
            // Convert the exponential value to operand1 string with desired format
            let expString;
            if (Number.isInteger(currentValue)) {
                expString = `${currentValue}.e+0`;
            } else {
                expString = exponentialValue.toExponential(0);
            }

            // Update the display with the exponential value
            document.getElementById('secondLinedisplay').innerText = expString;
        } else {
            // Handle case where exponential value is NaN
            document.getElementById('secondLinedisplay').innerText = 'NaN';
        }
    } else {
        // Handle case where currentValue is NaN
        document.getElementById('secondLinedisplay').innerText = 'NaN';
    }
});


// JavaScript code for the "F-E" button functionality
document.getElementById('notationButton').addEventListener('click', function() {
    // Get the current value in the display
    let currentValue = parseFloat(document.getElementById('secondLinedisplay').innerText);
    
    // Convert the value to scientific notation format (F-E)
    let scientificNotation = currentValue.toExponential();
    
    // Update the display with the scientific notation value
    document.getElementById('secondLinedisplay').innerText = scientificNotation;
});

//Memory Functions
        document.addEventListener('DOMContentLoaded', function() {
            // Function to enable memory buttons
            function enableMemoryButtons() {
                document.getElementById('mcButton').disabled = false;
                document.getElementById('mrButton').disabled = false;
            }
        
            // Function to disable memory buttons
            function disableMemoryButtons() {
                document.getElementById('mcButton').disabled = true;
                document.getElementById('mrButton').disabled = true;
            }
        
            // Initially disable memory buttons
            disableMemoryButtons();
        
            // Memory Functions
            document.getElementById('mcButton').addEventListener('click', function() {
                // Clear the memory register
                localStorage.removeItem('memory');
                // Update the memory display in the Memory section
                document.getElementById('memoryBlock').innerText = 'Memory: Empty';
                // Disable memory buttons again
                disableMemoryButtons();
            });
        
            document.getElementById('mrButton').addEventListener('click', function() {
                // Retrieve the value stored in the memory register and display it on the screen
                let memoryValue = localStorage.getItem('memory');
                if (memoryValue !== null) {
                    document.getElementById('secondLinedisplay').innerText = memoryValue; // Update the secondLinedisplay element with the memory value
                    document.getElementById('memoryBlock').innerText = 'Memory: ' + memoryValue;
                } else {
                    document.getElementById('secondLinedisplay').innerText = ''; // Clear the secondLinedisplay element if memory is empty
                    document.getElementById('memoryBlock').innerText = 'Memory: Empty';
                }
            });
        
            document.getElementById('msButton').addEventListener('click', function() {
                // Store the currently displayed value into the memory register
                let currentValue = parseFloat(document.getElementById('secondLinedisplay').innerText);
                localStorage.setItem('memory', currentValue.toString());
                // Update the memory display in the Memory section
                document.getElementById('memoryBlock').innerText = 'Memory: ' + localStorage.getItem('memory');
                // Enable memory buttons
                enableMemoryButtons();
            });
        
            
            document.getElementById('mPlusButton').addEventListener('click', function() {
                // Add the currently displayed value to the value stored in the memory register
                let currentValue = parseFloat(document.getElementById('secondLinedisplay').innerText);
                let memoryValue = localStorage.getItem('memory');
                if (memoryValue !== null) {
                    memoryValue = parseFloat(memoryValue);
                    localStorage.setItem('memory', (memoryValue + currentValue).toString());
                } else {
                    localStorage.setItem('memory', currentValue.toString());
                }
                // Update the memory display in the Memory section
                document.getElementById('memoryBlock').innerText = 'Memory: ' + localStorage.getItem('memory');
            });
        
            document.getElementById('mMinusButton').addEventListener('click', function() {
                // Subtract the currently displayed value from the value stored in the memory register
                let currentValue = parseFloat(document.getElementById('secondLinedisplay').innerText);
                let memoryValue = localStorage.getItem('memory');
                if (memoryValue !== null) {
                    memoryValue = parseFloat(memoryValue);
                    localStorage.setItem('memory', (memoryValue - currentValue).toString());
                } else {
                    localStorage.setItem('memory', currentValue.toString());
                }
                // Update the memory display in the Memory section
                document.getElementById('memoryBlock').innerText = 'Memory: ' + localStorage.getItem('memory');
            });

//History Functions

// Function to add an entry to the history
function addToHistory(entry) {
    let history = JSON.parse(localStorage.getItem('history')) || []; // Retrieve existing history or initialize as empty array
    history.push(entry); // Add the new entry to the history array
    localStorage.setItem('history', JSON.stringify(history)); // Save the updated history array back to localStorage
}

// Function to display history
function updateHistoryDisplay() {
    let historyList = document.getElementById('historyList');
    let history = JSON.parse(localStorage.getItem('history'));

    if (history && history.length > 0) {
        let historyItems = '';

        history.forEach((item, index) => {
            historyItems += `<li>${index + 1}. ${item}</li>`;
        });

        historyList.innerHTML = historyItems;
    } else {
        historyList.innerHTML = '<li>No history available.</li>';
    }
}

// Function to clear history
function clearHistory() {
    localStorage.removeItem('history'); // Remove history from localStorage
    updateHistoryDisplay(); // Update the history display
}

// Bind event listener to the clear history button
document.getElementById('clearHistory').addEventListener('click', clearHistory);

// Call updateHistoryDisplay when the page loads to display existing history
document.addEventListener('DOMContentLoaded', updateHistoryDisplay);
});

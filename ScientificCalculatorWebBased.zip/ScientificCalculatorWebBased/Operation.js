function operations(operand1, operand2, operator) {
    switch (operator) {
        case '+':
            return operand1 + operand2;
        case '-':
            return operand1 - operand2;
        case '*':
            return operand1 * operand2;
        case '/':
            if (operand2 === 0) {
                throw new Error("Cannot divide number by zero.");
            }
            return operand1 / operand2;
        case '^':
            return Math.pow(operand1, operand2);
        case '%':
            if (operand2 === 0) {
                throw new Error("Cannot perform modulus operation .");
            }
            return operand1 % operand2;
        default:
            throw new Error("Invalid operator: " + operator + "" + operand1 + "" + operand2);
    }
}

function precedence(operator1, operator2) {
    var precedence = {
        '(': 0,
        '+': 1,
        '-': 1,
        '*': 2,
        '/': 2,
        '%': 2,
        '^': 3,
    };
    return precedence[operator1] < precedence[operator2];
}


class Stack {
    constructor() {
        this.items = [];
    }

    push(element) {
        this.items.push(element);
    }

    pop() {
        if (this.isEmpty()) {
            return "Underflow";
        }
        return this.items.pop();
    }
    peek() {
        return !this.isEmpty() ? this.items[this.items.length - 1] : undefined;
    }

    isEmpty() {
        return this.items.length === 0;
    }
    size() {
        return this.items.length;
    }

    clear() {
        this.items = [];
    }
}



function bodmasApply(Expression) {
   
    let length = Expression.Length;
    let expressionIndex = 0;
    let operators = new Stack();
    let operands = new Stack();
    let numberIsNext = true;
    let number = "";
    let isCbracket = false;

    if (length === 0) {
        throw new Error("Please enter any expression.");
    }

    while (expressionIndex < Expression.length) {
        if ((Expression[expressionIndex] >= '0' && Expression[expressionIndex] <= '9') || Expression[expressionIndex] === '.') {
            number += Expression[expressionIndex];
            if (expressionIndex === Expression.length - 1 || (expressionIndex < Expression.length - 1 && !((Expression[expressionIndex + 1] >= '0' && Expression[expressionIndex + 1] <= '9') || Expression[expressionIndex + 1] === '.'))) {
                numberIsNext = false;
            }
            if (numberIsNext === false) {
                operands.push(parseFloat(number));
                number = "";
                numberIsNext = true;
            }

        } else if (Expression[expressionIndex] === '+' || Expression[expressionIndex] === '-' || Expression[expressionIndex] === '/' || Expression[expressionIndex] === '*' || Expression[expressionIndex] === '^' || Expression[expressionIndex] === '%') {
            if (operands.size() === 0 || Expression[expressionIndex - 1] === '(') {
                operands.push(0);
            }
            if (operators.size() === 0)
            {           
                operators.push(Expression[expressionIndex]);
            }
            else
            {
                if (precedence(operators.peek(), Expression[expressionIndex]) === true)
                {
                    operators.push(Expression[expressionIndex]);
                } else {
                    while (operators.size() !== 0 && (precedence(operators.peek(), Expression[expressionIndex]) === false)) {
                        let operand2 = operands.pop();
                        let operand1 = operands.pop();
                        operands.push(operations(operand1, operand2, operators.peek()));
                        operators.pop();
                    }
                    operators.push(Expression[expressionIndex]);
                }
            }

        } else if (Expression[expressionIndex] === '(' || Expression[expressionIndex] === ')') {
            
            if (Expression[expressionIndex] === '(') {
                isCbracket = true;
                operators.push(Expression[expressionIndex]);

            } else {

                while (operators.peek() !== '(' && isCbracket === true) {
                    let operand2 = operands.pop();
                    let operand1 = operands.pop();
                    operands.push(operations(operand1, operand2, operators.peek()));
                    operators.pop();
                }
                isCbracket = false;
                operators.pop();
            }

        }
        expressionIndex++;
        if (expressionIndex === Expression.length && operators.size() !== 0) {
            if (isCbracket === true) {
                throw new Error('Closing bracket not found ${Expression}');
            }
            while (operators.size() !== 0) {
                let operand2 = operands.pop();
                let operand1 = operands.pop();
                operands.push(operations(operand1, operand2, operators.peek()));
                operators.pop();
            }
        }
    }
    return operands.peek();
}

// TrignometricOperations
function AngleChanger(angle, status) {
    if (status === "DEG") {
        if (angle >= 360) {
            angle %= 360;
        }
        angle = (angle * Math.PI) / 180;
    } else if (status === "GRAD") {
        if (angle >= 400) {
            angle %= 400;
        }
        angle = (angle * Math.PI) / 200;
    } else {
        if (angle >= (2 * Math.PI)) {
            angle %= (2 * Math.PI);
        }
    }
    return angle;
}

function ValueChanger(angle, status) {
    if (status === "DEG") {
        angle *= 180 / Math.PI;
    } else if (status === "GRAD") {
        angle *= 200 / Math.PI;
    }
    return angle;
}

// Trigonometric Function
function Sine(angle, Status) {
    angle = AngleChanger(angle, Status);
    return Math.sin(angle);
}

function Cosine(angle, Status) {
    angle = AngleChanger(angle, Status);
    return Math.cos(angle);
}

function Tangent(angle, Status) {
    angle = AngleChanger(angle, Status);
    let tempValue = Math.tan(angle);
    if (tempValue > -58.0 && tempValue < 58.0) {
        return tempValue;
    } else {
        return NaN;
    }
}

function Cot(angle, Status) {
    let tempValue = Tangent(angle, Status);
    if (isNaN(tempValue)) {
        return 0;
    }
    return 1 / tempValue;
}

function Sec(angle, Status) {
    return 1 / Cosine(angle, Status);
}

function Cosec(angle, Status) {
    return 1 / Sine(angle, Status);
}

// Inverse Trigonometric Function
function SineInverse(angle, Status) {
    let temp = Math.asin(angle);
    return ValueChanger(temp, Status);
}

function CosineInverse(angle, Status) {
    let temp = Math.acos(angle);
    return ValueChanger(temp, Status);
}

function TangentInverse(angle, Status) {
    let temp = Math.atan(angle);
    return ValueChanger(temp, Status);
}

function CotInverse(angle, Status) {
    return TangentInverse(1 / angle, Status);
}

function SecInverse(angle, Status) {
    return CosineInverse(1 / angle, Status);
}

function CosecInverse(angle, Status) {
    return SineInverse(1 / angle, Status);
}

// Hyperbolic Function
function SineHyp(angle) {
    return Math.sinh(angle);
}

function CosineHyp(angle) {
    return Math.cosh(angle);
}

function TangentHyp(angle) {
    return Math.tanh(angle);
}

function CotHyp(angle) {
    return 1 / TangentHyp(angle);
}

function SecHyp(angle) {
    return 1 / CosineHyp(angle);
}

function CosecHyp(angle) {
    return 1 / SineHyp(angle);
}

// Inverse Hyperbolic Function
function SineHypInverse(angle) {
    return Math.asinh(angle);
}

function CosineHypInverse(angle) {
    return Math.acosh(angle);
}

function TangentHypInverse(angle) {
    return Math.atanh(angle);
}

function CotHypInverse(angle) {
    return 1 / TangentHypInverse(angle);
}

function SecHypInverse(angle) {
    return CosineHypInverse(1 / angle);
}

function CosecHypInverse(angle) {
    return SineHypInverse(1 / angle);
}
